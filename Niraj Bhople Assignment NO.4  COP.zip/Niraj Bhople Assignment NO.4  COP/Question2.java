package Assignment;

import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //  wap to ask 5 names from user and check if particular name exists in array or not .
		int a[]=new int[5]; int n,count =0;
		Scanner r=new Scanner (System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=r.nextInt();
			
		}
		System.out.println("Array Element ");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]+" ");
			
		}
		System.out.println("Entre search Element ");
	n=r.nextInt();
	for(int i=0; i<a.length; i++)
	{if(a[i]==n)
	{
		count++;
	}
	 if(count>0)
		 System.out.println("Item Found" +count+ "times");
	 else
		 System.out.println("Item is not Found");
	}
	}
		

}
