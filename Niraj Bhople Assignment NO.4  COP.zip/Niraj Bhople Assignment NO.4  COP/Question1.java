package Assignment;

import java.util.Scanner;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // 1 wap to define an array of integer of size 6 .Take input from user and display it in reverse order
		int a[]=new int [6];
		Scanner r=new Scanner(System.in);
		System.out.print("Entre element in array");
		for (int i=0; i<a.length; i++)
		{
			a[i]=r.nextInt();
			
		}
		System.out.println("array element ");
		for (int i=0; i<6; i++)
		{
			System.out.println(a[i]+" ");
		}
			System.out.print("\n array reverse elements");
			for(int i=a.length-1; i>=0; i--)
			{
				System.out.print(a[i]+ " ");
			}
			
	}

}
